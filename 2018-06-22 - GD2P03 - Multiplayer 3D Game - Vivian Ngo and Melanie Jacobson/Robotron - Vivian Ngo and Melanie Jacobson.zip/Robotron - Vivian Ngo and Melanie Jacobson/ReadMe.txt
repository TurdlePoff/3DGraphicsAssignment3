Things we did
- Lobby exists for both client and server (Host Server + Host Client)
- Can host server and client can connect to it
- Can launch client which will discover 1 server and once connected it will display the server ip on the game window
- Can only accept input in console
- Have coded different ways to convert data types in Utils.h but sadly didn't have time to use it

Issues
- Cant play game together
- Cant select via game window but can hover over ip on client side.
- Server works like console after hosting